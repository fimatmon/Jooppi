Username: Testaaja
Password: 1234Test

Windows:
Unpack for example to a folder: C:\Temp\JooppiV1.4
Launch Jooppi.bat

Other:
Launch it from the console: java -jar JooppiV1.4.jar